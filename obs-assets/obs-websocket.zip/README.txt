This is a custom build of obs-websocket, built against OBS 31.0.3, based on this PR to add more information when transitioning:
https://github.com/obsproject/obs-websocket/pull/1229
