This is a custom build of obs-websocket, built against OBS 32.0.0, based on this PR to add more information when transitioning:
https://github.com/obsproject/obs-websocket/pull/1229
